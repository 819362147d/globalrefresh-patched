//
// BackgroundTaskChain.swift
// pip_swift
//
// 极限保活：iOS 原生后台任务链
//
// 原理（iOS 原生机制优先）：
// - scene 进入后台时申请后台任务；iOS 给的后台时间用完前，系统会调用
// expiration handler；我们在 handler 里结束旧任务并立即申请新任务，
// 形成任务链，把后台存活时间拉到 iOS 允许的极限。
// - 静音音频保活仍是主力（无限时长）；本链覆盖音频未启用时的空窗期，
// 以及音频被系统打断后的过渡期。
// - 用户主动上滑杀掉 App 时，任何保活手段都会失效，这是 iOS 铁律。
//

import UIKit

final class BackgroundTaskChain {
    static let shared = BackgroundTaskChain()

    private var taskID: UIBackgroundTaskIdentifier = .invalid
    private let lock = NSLock()
    private var chainCount = 0

    private init() {}

    /// 进入后台时调用，开始任务链
    func start() {
        lock.lock()
        defer { lock.unlock() }
        endLocked()
        chainCount = 0
        armLocked()
    }

    /// 回到前台时调用，释放后台任务（前台不需要占着）
    func stop() {
        lock.lock()
        defer { lock.unlock() }
        if chainCount > 0 {
            AppDebugLogger.log("后台任务链结束，共续接 \(chainCount) 次")
        }
        chainCount = 0
        endLocked()
    }

    private func armLocked() {
        let id = UIApplication.shared.beginBackgroundTask(
            withName: "com.communitypatch.keepalive.chain"
        ) { [weak self] in
            // 时间将用尽：结束旧任务，立即续接新任务
            self?.renew()
        }
        if id == .invalid {
            AppDebugLogger.logCritical("后台任务链申请失败：系统拒绝（已到极限）")
            taskID = .invalid
            return
        }
        taskID = id
    }

    private func renew() {
        lock.lock()
        defer { lock.unlock() }
        endLocked()
        chainCount += 1
        armLocked()
        if taskID != .invalid {
            AppDebugLogger.log("后台任务链续接第 \(chainCount) 次")
        }
    }

    private func endLocked() {
        if taskID != .invalid {
            UIApplication.shared.endBackgroundTask(taskID)
            taskID = .invalid
        }
    }
}
