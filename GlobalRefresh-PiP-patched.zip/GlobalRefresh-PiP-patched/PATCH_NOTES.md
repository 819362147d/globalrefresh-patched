# 社区补丁说明（基于 v1.1.1 / 构建号 2026100902）

补丁构建号：`2026101101`（Info.plist 里可查 `GRPCommunityPatch` 字段）

本补丁只做**稳定性加固**，不改变 App 的功能定位。补丁作者未在真机上编译验证，
构建前请知悉：云端构建成功只代表编译通过，不代表真机行为已验证。

## 补丁 1：私有 API 加系统版本门禁（P0）

文件：`pip_swift/pip_swift/PiPCoexistenceExperiment.swift`

原代码在任何 iOS 版本上都会尝试替换（swizzle）苹果私有类
`AVPictureInPicturePlatformAdapter` 的 `_proxyControlsStyle` 方法。
苹果一旦在新系统里改掉这个私有实现，App 就会闪退。

改动：
- 新增 `maxValidatedOSMajorVersion = 26`：只有 iOS 26 及以下默认走私有 hook；
- 新系统需要用户在设置里显式打开 opt-in（UserDefaults 键
  `pip.hiddenReference.allowUntestedOS`，已预留 `setUntestedOSOptedIn` 接口，
  UI 开关可后续接上），否则自动降级到标准 PiP 路线；
- iOS 27 发布后，**必须在真机验证通过后**手动把 `maxValidatedOSMajorVersion`
  改大，不能直接改数字。

## 补丁 2：hook 不可用时降级而非静默失败（P0）

文件：`pip_swift/pip_swift/ViewController.swift`（`setupPip`）

原代码中 `makeController` 返回 nil 时 `pipController` 保持 nil，
随后的 `guard` 直接 return，用户点了"开启悬浮窗"却什么都没发生。

改动：hook 不可用时自动用标准 `AVPictureInPictureController(contentSource:)`
重建，走普通 VideoCall 路线，保证功能可用。

## 补丁 3：KVC 访问私有属性前先探测（P0）

文件：`pip_swift/pip_swift/ViewController.swift`（`applyPiPControlsStyle`）

`setValue(_:forKey: "controlsStyle")` 在新系统上 key 不存在时会抛
`NSUnknownKeyException` 直接崩溃。改动：先用
`responds(to: "setControlsStyle:")` 探测，不存在就跳过（只损失自定义
控制栏样式，安全方向）。

## 补丁 4：连续启动失败熔断（P1）

文件：`pip_swift/pip_swift/ViewController.swift`

- 成功启动 PiP 时清零 `consecutivePiPStartFailures`；
- 连续 5 次启动失败且当前是隐藏实验路线时，置位
  `hiddenReferenceCircuitBroken`，本会话内后续启动全部走标准路线，
  不再对一条系统性走不通的路反复重试耗电。

## 诚实声明

以上补丁**不能**实现以下目标（iOS 架构限制，与代码无关）：
- 让王者荣耀等前台游戏锁定 120 帧；
- 修改触控采样率；
- 在 60Hz 屏幕上变出 120Hz。

## 后续可接的工作（未做）

- 把 `allowUntestedOS` 接到设置页 UI 开关；
- 四个 CADisplayLink 合并为一个（省电，改动面大，未做）；
- 高频路径 260 处强制解包审计（未做）。

## 补丁 5：移除 iOS 27 专属 MetricKit 代码，兼容 Xcode 26 构建（构建修复）

文件：`pip_swift/pip_swift/MetricKitLogger.swift`

原因：原代码引用了只存在于 iOS 27 SDK 的新 API
（`MetricManager` / `MetricReport` / `DiagnosticReport`），
Codemagic 的 Xcode 26.6（iOS 26.5 SDK）编译时报
`cannot find type 'MetricReport' in scope` 共 12 处错误，
`@available(iOS 27.0, *)` 救不了（编译期类型解析失败）。

改动：删除 `IOS27MetricKitBridge` 类及所有引用上述类型的函数
（`handleModernMetricReport` / `handleModernDiagnosticReport` /
`modernMetricSummary` / `appendModernEvent` / `formatDateRange`），
以及 `start()` / `stop()` 中的 iOS 27 分支。

安全性：这些代码只是 App 自身的调试遥测，且在 Release 包中
本就不执行（`start()` 首行有 `isDebugModeEnabled` 开关），
删除不影响任何功能。如需恢复，用带 iOS 27 SDK 的 Xcode 重新构建即可。
