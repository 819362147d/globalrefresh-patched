# 社区补丁说明（基于 v1.1.1 / 构建号 2026100902）

补丁构建号：`2026101104`（Info.plist 里可查 `GRPCommunityPatch` 字段）

本补丁只做**稳定性加固**，不改变 App 的功能定位。补丁作者未在真机上编译验证，
构建前请知悉：云端构建成功只代表编译通过，不代表真机行为已验证。

## 补丁 1：私有 API 加系统版本门禁（P0）

文件：`pip_swift/pip_swift/PiPCoexistenceExperiment.swift`

原代码在任何 iOS 版本上都会尝试替换（swizzle）苹果私有类
`AVPictureInPicturePlatformAdapter` 的 `_proxyControlsStyle` 方法。
苹果一旦在新系统里改掉这个私有实现，App 就会闪退。

改动：
- 新增 `maxValidatedOSMajorVersion = 26`：只有 iOS 26 及以下默认走私有 hook；
- 新系统需要用户在设置里显式打开 opt-in（UserDefaults 键
  `pip.hiddenReference.allowUntestedOS`，已预留 `setUntestedOSOptedIn` 接口，
  UI 开关可后续接上），否则自动降级到标准 PiP 路线；
- iOS 27 发布后，**必须在真机验证通过后**手动把 `maxValidatedOSMajorVersion`
  改大，不能直接改数字。

## 补丁 2：hook 不可用时降级而非静默失败（P0）

文件：`pip_swift/pip_swift/ViewController.swift`（`setupPip`）

原代码中 `makeController` 返回 nil 时 `pipController` 保持 nil，
随后的 `guard` 直接 return，用户点了"开启悬浮窗"却什么都没发生。

改动：hook 不可用时自动用标准 `AVPictureInPictureController(contentSource:)`
重建，走普通 VideoCall 路线，保证功能可用。

## 补丁 3：KVC 访问私有属性前先探测（P0）

文件：`pip_swift/pip_swift/ViewController.swift`（`applyPiPControlsStyle`）

`setValue(_:forKey: "controlsStyle")` 在新系统上 key 不存在时会抛
`NSUnknownKeyException` 直接崩溃。改动：先用
`responds(to: "setControlsStyle:")` 探测，不存在就跳过（只损失自定义
控制栏样式，安全方向）。

## 补丁 4：连续启动失败熔断（P1）

文件：`pip_swift/pip_swift/ViewController.swift`

- 成功启动 PiP 时清零 `consecutivePiPStartFailures`；
- 连续 5 次启动失败且当前是隐藏实验路线时，置位
  `hiddenReferenceCircuitBroken`，本会话内后续启动全部走标准路线，
  不再对一条系统性走不通的路反复重试耗电。

## 诚实声明

以上补丁**不能**实现以下目标（iOS 架构限制，与代码无关）：
- 让王者荣耀等前台游戏锁定 120 帧；
- 修改触控采样率；
- 在 60Hz 屏幕上变出 120Hz。

## 后续可接的工作（未做）

- 把 `allowUntestedOS` 接到设置页 UI 开关；
- 四个 CADisplayLink 合并为一个（省电，改动面大，未做）；
- 高频路径 260 处强制解包审计（未做）。

## 补丁 5：移除 iOS 27 专属 MetricKit 代码，兼容 Xcode 26 构建（构建修复）

文件：`pip_swift/pip_swift/MetricKitLogger.swift`

原因：原代码引用了只存在于 iOS 27 SDK 的新 API
（`MetricManager` / `MetricReport` / `DiagnosticReport`），
Codemagic 的 Xcode 26.6（iOS 26.5 SDK）编译时报
`cannot find type 'MetricReport' in scope` 共 12 处错误，
`@available(iOS 27.0, *)` 救不了（编译期类型解析失败）。

改动：删除 `IOS27MetricKitBridge` 类及所有引用上述类型的函数
（`handleModernMetricReport` / `handleModernDiagnosticReport` /
`modernMetricSummary` / `appendModernEvent` / `formatDateRange`），
以及 `start()` / `stop()` 中的 iOS 27 分支。

安全性：这些代码只是 App 自身的调试遥测，且在 Release 包中
本就不执行（`start()` 首行有 `isDebugModeEnabled` 开关），
删除不影响任何功能。如需恢复，用带 iOS 27 SDK 的 Xcode 重新构建即可。

## 补丁 6：隐藏悬浮窗帧率拉满到 120（用户要求，2026-10-11）

文件：`pip_swift/pip_swift/PiPCoexistenceExperiment.swift`
（`PiPHiddenReferenceOptions`）

改动两处：
- `contentFramesPerSecond`：60 → 120。隐藏 1pt PiP 内容的
  CADisplayLink 按 120fps 跑（`min(120, UIScreen.main.maximumFramesPerSecond)`，
  60Hz 屏幕不受影响）。
- `requests120`：false → true。此前为保守策略，代码里显式压制了严格
  120Hz 刷新请求（`suppressesStrictRefreshRequest`），后台刷新驱动
  DisplayLink 不设 `preferredFrameRateRange`；打开后走严格区间，
  目标 `min(120, 屏幕最大帧率)`。

效果与代价（已告知用户）：
- 可能让系统刷新率更容易顶到 120Hz；**不改变前台游戏的渲染帧率**，
  王者该多少帧还是多少帧。
- 120fps 常驻渲染更费电、发热更高，重度使用（打游戏）时注意发热降频。

## 补丁 7：极限保活之后台任务链（用户要求，2026-10-11）

新增文件：`pip_swift/pip_swift/BackgroundTaskChain.swift`
（已注册进 `project.pbxproj` 的 Sources 编译阶段）
修改文件：`pip_swift/pip_swift/SceneDelegate.swift`
（`sceneDidEnterBackground` 启动任务链，`sceneDidBecomeActive` 释放）

原理（iOS 原生机制优先）：
- 进入后台时 `beginBackgroundTask` 申请后台任务；iOS 回收时间前触发
  expiration handler，在 handler 里结束旧任务并立即申请新任务，
  形成任务链，把后台存活拉到 iOS 允许的极限。
- 静音音频保活仍是主力（理论无限时长）；本链覆盖音频未启用时的空窗期。
- 用户主动上滑杀进程时任何保活都失效，这是 iOS 铁律，无解。

未做的更激进选项（有代价，需用户决定）：
- `location` 后台模式：保活最强之一，但要弹"始终允许定位"授权，
  常驻定位箭头、显著耗电。
- 静默推送保活：需要自建 APNs 服务器，目前没有这套基建。

## 补丁 8：极限保活之定位保活（用户要求"全上"，2026-10-11）

新增文件：`pip_swift/pip_swift/LocationKeepAlive.swift`
（已注册进 `project.pbxproj`）
修改文件：
- `Info.plist`：`UIBackgroundModes` 增加 `location`；
  新增 `NSLocationAlwaysAndWhenInUseUsageDescription` /
  `NSLocationWhenInUseUsageDescription` 授权文案。
- `SceneDelegate.swift`：进后台启动定位保活，回前台停止。
- `AppDelegate.swift`：启动时触发一次"始终允许"授权弹窗。

策略：精度用 3 公里档（保活不需要精度，尽量省电），
`pausesLocationUpdatesAutomatically = false`（不许系统自动暂停），
`allowsBackgroundLocationUpdates = true`。

代价（已告知用户）：状态栏定位箭头常驻、额外耗电；
用户必须在弹窗选"始终允许"，否则后台保活不生效。

未上（上不了）：静默推送保活——需要 Apple 开发者账号（$99/年）
的 APNs 证书签发推送，目前没有该基建；用户购买开发者账号后可再接。




---

## 2026-10-11 16:56 构建修复：LocationKeepAlive.swift 空格损坏

- Codemagic 编译失败：`LocationKeepAlive.swift` 中 `== .` / `!= .` / `if !` 的空格被吞掉、
  全文件缩进丢失，导致 `expected '{' after 'if' condition` 等语法错误。
- 根因：通过 muse.write 写入该文件时内容被损坏（两次重写均复现）；
  改用 `exec` + heredoc 直写后文件完好。教训：若发现 write 后 Swift 语法异常，
  立即用 `grep -c "==\."` 检查，改用 heredoc 重写。
- 已重新打包，构建号保持 2026101104（该构建号尚未成功编译过，无需递增）。
